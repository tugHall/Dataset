
library(stringr)   # to use string data in input files
library(actuar)    # to use BIG NUMBERS in N_cell variable
library(ggplot2)




### Discrete data for Compaction factor
dt_set <- c( 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0 )

num <- 40000

header <- c('Ha', 'Hb', 'Hd', 'Hi', 'Him' )

name_weights   <-   c( 'Discrete'      ,       'Continuous' )[1]
init_file <-  paste0( 'Compaction_Factor_', name_weights, '.txt' )

write(header, file = init_file, append = FALSE, ncolumn=length(header), sep="\t")


for (i in 1:num) {
    
    data   <-  sample(dt_set, 5, replace = TRUE)
    write( data,   file = init_file, append = TRUE,  ncolumn=length(data),   sep="\t" )
    
}


### Continuous data for Compaction factor
name_weights   <-   c( 'Discrete'      ,       'Continuous' )[2]
init_file <-  paste0( 'Compaction_Factor_', name_weights, '.txt' )

write(header, file = init_file, append = FALSE, ncolumn=length(header), sep="\t")

for (i in 1:num) {
    
    data   <-  round( runif(5, min = 0.1, max = 1) , digits = 4)
    write( data,   file = init_file, append = TRUE,  ncolumn=length(data),   sep="\t" )
    
}




############## We have to plot PRIMARY distribution


b_ggpl <- function(data.sim, x_l = "x axis", y_l = "y axis", title = "") {
    
    g <- ggplot(data = data.sim, aes(x = Count, fill = Variable), xlab = "" )
    qb <- geom_histogram(position = "dodge", alpha=0.75, main = title)
    
    ax <- theme(axis.text.x = element_text(face="bold",      # color="#993333", 
                                           size=14, angle=0),
                axis.text.y = element_text(face="bold",      # color="#993333", 
                                           size=14, angle=0),
                axis.title.x = element_text(face="bold",       color="#FF3333", 
                                            size=24, angle=0),
                axis.title.y = element_text(face="bold",       color="#FF3333", 
                                            size=24, angle=90),
                title   = element_text(face="bold",       color="#0033FF", 
                                       size=18, angle=0),
    )
    # ax1 <- scale_x_discrete(x_l, labels=data.sim$Variable) 
    ax1 <- scale_x_continuous(name = x_l) 
    ax2 <- scale_y_continuous(name = y_l) 
    t <- ggtitle(title)
    tk <- labs(fill = "Genes")
    print(g + qb + ax + ax1 + ax2 + t + tk)
}


save_fig <- function(file_input) {
    file_input <- paste0(substr(file_input,1,nchar(file_input)-4),".jpg")
    #dev.copy2eps(file = file_input, height = 10, width = 10) 
    dev.copy(jpeg,file_input, width = 10, height = 10, units = 'in', res = 300)
    dev.off()
    par(xpd=TRUE, cex.lab=2, lwd = 2, mar = c(5, 5, 5, 5), tcl = 0.5, cex.axis = 1.75,  mgp = c(3, 0.6, 0))
}




ck <- read.table(file = init_file, header = TRUE, sep = "\t")



# header <- c('Ha', 'Hb', 'Hd', 'Hi', 'Him' )

ck.df   <-   data.frame( Variable = c( rep( 'Ha', num), rep( 'Hb', num), rep( 'Hd', num), rep( 'Hi', num), rep( 'Him', num) ) ,
                         Count = c( ck$Ha[1:num], ck$Hb[1:num], ck$Hd[1:num], ck$Hi[1:num], ck$Him[1:num] ) )

b_ggpl(data.sim = ck.df, x_l = "Values", y_l = "", title = "Compaction Factor")

save_fig("Comp_Factor_Discrete.jpg")




