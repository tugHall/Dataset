

##########################################################################################
###  The simulation uses the functions and classes in the "Code/tugHall_2.1_functions.R" 

library(stringr)   # to use string data in input files
library(actuar)    # to use BIG NUMBERS in N_cell variable
library(ggplot2)

source(file = "Code/tugHall_2.1_functions.R")

name_weights   <<-   'Discrete'             #  'Discrete'      or       'Continuous'

## Create folders:  /Input, /Output and /Figures 

mainDir <- getwd()
subDir <- "Output"
if (! file.exists(subDir)){  dir.create(file.path(mainDir, subDir)) }

subDir <- "Input"
if (! file.exists(subDir)){  dir.create(file.path(mainDir, subDir)) }

subDir <- "Figures"
if (! file.exists(subDir)){  dir.create(file.path(mainDir, subDir)) }


##########################################################################################
### Files to output and input data

genefile <- 'Input/gene_cds2.txt'    # gene file 
clonefile <- 'Input/cloneinit.txt'     # initial Cells 

### Output files
geneoutfile <- 'Output/geneout.txt'  # Gene Out file with Hallmarks 
cloneoutfile <- 'Output/cloneout.txt'  # output information of simulation
logoutfile <-  'Output/log.txt'      # log file to save the input information of simulation - "log.txt"
### Output/Weights.txt               # file with gene weights for hallmarks

##########################################################################################
# Probabilities of processes

E0 <<-  1E-4       # parameter in the division probability  
F0 <<-  10         # parameter in the division probability  
m0 <<-  4E-8       # mutation probability  
uo <<-  0.5        # oncogene mutation probability  
us <<-  0.5        # suppressor mutation probability  
s0 <<-  10         # parameter in the sigmoid function  
k0 <<-  0.2        # Environmental death probability  
d0 <<-  0.35   # Initial probability to divide cells
### Additional parameters of simulation
censore_n <<- 10^4       # Max cell number where the program forcibly stops
censore_t <<- 20         # Max time where the program forcibly stops




## Define initial halmarks and genes and weights (we will change it later)

onco <<- oncogene$new()        # make the vector onco about the hallmarks
onco$read(genefile)          # read the input info to the onco from genefile - 'gene_cds2.txt'
hall <<- hallmark$new()        # make a vector hall with hallmarks parameters
hall$read(genefile, onco$name)     # read from the genefile - 'gene_cds2.txt'


### Here we have a rule that sum of weights = 1 and weights should be from values of the data set (dt_set):
dt_set <- c( 0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0 )

SAM_discrete <- function( dt_set = dt_set, number_of_weights ){
    ### Function to generate weights from data set "dt_set"
    weights <- NULL
    l <- length(dt_set)             # length (l) of data set 
    p <- sort( sample( (1:l), (number_of_weights-1), replace = FALSE ) )     # choose the points (p) in the data set
    
    weights[1] <- dt_set[p[1]]
    if (number_of_weights > 2) {
        for (i in 2:(number_of_weights-1)) {
            weights[i] <- dt_set[p[i]] - dt_set[p[i-1]]
        }
    }
    
    weights[number_of_weights] <-  round( 1.0 - sum(weights[1:(number_of_weights-1)]) , digits = 3)
    weights_shuffled <- sample(weights)
    
    
    return(weights_shuffled)
}



SAM_continuous <- function( number_of_weights ){
  ### Function to generate continuous weights from [0;1]
  weights <- NULL
  n_r <- number_of_weights -1
  r <- runif(n_r)
  r <- sort(r)
  
  weights[1] <- r[1]
  
  if (n_r > 1) {
    for (i in 2:n_r) {
      weights[i] <- r[i] - r[i-1]
    }
  }
  
  weights[number_of_weights] <-  1.0 - sum(weights[1:n_r])
  
  return(weights)
}

SAM <- function(dt_set = dt_set, number_of_weights) {

    if ( name_weights   ==   'Discrete' ) {
        weights <- SAM_discrete( dt_set = dt_set, number_of_weights )
    } else {
        weights <- SAM_continuous( number_of_weights )
    }

}



Gen_Weights <- function(hall = hall) {    
    ## WEIGHTS FOR APOPTOSIS HALLMARK
    hall$Ha_w <- SAM(dt_set = dt_set, number_of_weights = 4)    
    
    ## WEIGHTS FOR ANGIOGENESIS HALLMARK
    hall$Hb_w <- SAM(dt_set = dt_set, number_of_weights = 3)    
    
    ## WEIGHTS FOR GROWTH/ANTIGROWTH HALLMARK
    hall$Hd_w <- SAM(dt_set = dt_set, number_of_weights = 4)    
    
    ## WEIGHTS FOR IMMORTALIZATION HALLMARK
    hall$Hi_w <- SAM(dt_set = dt_set, number_of_weights = 2)    
    
    ## WEIGHTS FOR INVASION/METASTASIS HALLMARK
    hall$Him_w <- SAM(dt_set = dt_set, number_of_weights = 4)   

    return(hall)
}


header <- c('Simulation_ID', 'Mutated_Gene', 
            'E0', 'F0', 'm0', 'uo', 'us', 's0', 'k0', 'd0', 
            paste('w_Ha_',onco$name[hall$Ha], sep = ""),
            paste('w_Hb_',onco$name[hall$Hb], sep = ""),
            paste('w_Hd_',onco$name[hall$Hd], sep = ""),
            paste('w_Hi_',onco$name[hall$Hi], sep = ""),
            paste('w_Him_',onco$name[hall$Him], sep = "")
)


################### Write the file with initial parameters and weights of hallmarks

init_file <-  paste0( 'Initial_parameters_', name_weights, '.txt' )
write(header, file = init_file, append = FALSE, ncolumn=length(header), sep="\t")

i <- 1
repeat { 
    hall <- Gen_Weights(hall = hall)
    
    for ( g in onco$name ) {
        data   <- c(i, g,
                    E0, F0, m0, uo, us, s0, k0, d0,
                    hall$Ha_w,
                    hall$Hb_w,
                    hall$Hd_w,
                    hall$Hi_w,
                    hall$Him_w
        ) 
        
        write(data,   file = init_file, append = TRUE,  ncolumn=length(data),   sep="\t")
        i <- i + 1   # use same weights for different genes
    }
    
    if (i >= 40000 ) break
}



ck <- read.table(file = init_file, header = TRUE, sep = "\t")



############## We have to plot PRIMARY distribution


b_ggpl <- function(data.sim, x_l = "x axis", y_l = "y axis", title = "") {
  
  g <- ggplot(data = data.sim, aes(x = Count, fill = Variable), xlab = "" )
  qb <- geom_histogram(position = "dodge", alpha=0.75, main = title)
  
  ax <- theme(axis.text.x = element_text(face="bold",      # color="#993333", 
                                         size=14, angle=0),
              axis.text.y = element_text(face="bold",      # color="#993333", 
                                         size=14, angle=0),
              axis.title.x = element_text(face="bold",       color="#FF3333", 
                                          size=24, angle=0),
              axis.title.y = element_text(face="bold",       color="#FF3333", 
                                          size=24, angle=90),
                   title   = element_text(face="bold",       color="#0033FF", 
                                          size=18, angle=0),
  )
  # ax1 <- scale_x_discrete(x_l, labels=data.sim$Variable) 
  ax1 <- scale_x_continuous(name = x_l) 
  ax2 <- scale_y_continuous(name = y_l) 
  t <- ggtitle(title)
  tk <- labs(fill = "Genes")
  print(g + qb + ax + ax1 + ax2 + t + tk)
}


save_fig <- function(file_input) {
  file_input <- paste0(substr(file_input,1,nchar(file_input)-4),".jpg")
  #dev.copy2eps(file = file_input, height = 10, width = 10) 
  dev.copy(jpeg,file_input, width = 10, height = 10, units = 'in', res = 300)
  dev.off()
  par(xpd=TRUE, cex.lab=2, lwd = 2, mar = c(5, 5, 5, 5), tcl = 0.5, cex.axis = 1.75,  mgp = c(3, 0.6, 0))
}


num <- 40000

### Ha
ck.df <- data.frame( Variable = c( rep('APC', num), rep('KRAS', num), rep('TP53', num), rep('PIK3CA', num)  ), 
                        Count = c(ck$w_Ha_APC[1:num], ck$w_Ha_KRAS[1:num], ck$w_Ha_TP53[1:num],ck$w_Ha_PIK3CA[1:num]) )   #  as.numeric(t(cs)) )

b_ggpl(data.sim = ck.df, x_l = "Weights", y_l = "", title = "Apoptosis hallmark")
save_fig("Ha.jpg")


### Hb
ck.df <- data.frame( Variable = c(  rep('KRAS', num), rep('TP53', num), rep('PIK3CA', num)  ), 
                     Count = c( ck$w_Hb_KRAS[1:num], ck$w_Hb_TP53[1:num],ck$w_Hb_PIK3CA[1:num]) )   #  as.numeric(t(cs)) )

b_ggpl(data.sim = ck.df, x_l = "Weights", y_l = "", title = "Angiogenesis hallmark")
save_fig("Hb.jpg")



### Him:
ck.df <- data.frame( Variable = c( rep('APC', num), rep('KRAS', num), rep('TP53', num), rep('PIK3CA', num)  ), 
                     Count = c(ck$w_Him_APC[1:num], ck$w_Him_KRAS[1:num], ck$w_Him_TP53[1:num],ck$w_Him_PIK3CA[1:num]) )   #  as.numeric(t(cs)) )

b_ggpl(data.sim = ck.df, x_l = "Weights", y_l = "", title = "Invasion/metastasis hallmark")
save_fig("Him.jpg")




### Hi:
ck.df <- data.frame( Variable = c(  rep('KRAS', num), rep('TP53', num)  ), 
                     Count = c(ck$w_Hi_KRAS[1:num], ck$w_Hi_TP53[1:num] ) )   #  as.numeric(t(cs)) )

b_ggpl(data.sim = ck.df, x_l = "Weights", y_l = "", title = "Immortalization hallmark")
save_fig("Hi.jpg")




### Hd
ck.df <- data.frame( Variable = c( rep('APC', num), rep('KRAS', num), rep('TP53', num), rep('PIK3CA', num)  ), 
                     Count = c(ck$w_Hd_APC[1:num], ck$w_Hd_KRAS[1:num], ck$w_Hd_TP53[1:num],ck$w_Hd_PIK3CA[1:num]) )   #  as.numeric(t(cs)) )


b_ggpl(data.sim = ck.df, x_l = "Weights", y_l = "", title = "Growth/antigrowth hallmark")

save_fig("Hd.jpg")



